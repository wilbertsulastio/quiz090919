﻿
using System;

namespace Quiz09092019
{
    class Program
    {
        static void Main(string[] args)
        {
            BangunDatar obj = new BangunDatar();

            obj.LuasPersegi();

            obj.LuasSegitiga();

        
            obj.LuasLingkaran();

            obj.BangunRuang();

        }    
    }        
}
