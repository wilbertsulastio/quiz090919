using System;

namespace Quiz09092019
{
    class BangunRuang
    {
        public void VolumeBalok()
        {
            int panjang, lebar, tinggi;

            Console.WriteLine("Menghitung Volume Balok");

            Console.Write("Masukkan Nilai Panjang :");
            panjang = Convert.ToInt32(Console.ReadLine());

            Console.Write("Masukkan Nilai Lebar :");
            lebar = Convert.ToInt32(Console.ReadLine());

            Console.Write("Masukkan Nilai Tinggi :");
            tinggi = Convert.ToInt32(Console.ReadLine());


           int Volume = panjang * lebar * tinggi ;


            Console.WriteLine("Volume Balok Adalah "+Volume );

        }

        public void VolumeKubus()
        {
            int sisi ;
            Console.WriteLine("Menghitung Volume Kubus");

            Console.Write("Masukkan Nilai sisi :");
            sisi = Convert.ToInt32(Console.ReadLine());

            int volume = sisi * sisi * sisi ;

            Console.WriteLine("Volume Kubus adalah "+volume);
        }

































    }
 
}

